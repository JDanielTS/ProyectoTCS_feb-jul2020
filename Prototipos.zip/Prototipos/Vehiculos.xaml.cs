﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prototipos
{
    /// <summary>
    /// Lógica de interacción para Vehiculos.xaml
    /// </summary>
    public partial class Vehiculos : Window
    {
        public Vehiculos()
        {
            InitializeComponent();
        }
        private void Btn_Nuevo_Click(object sender, RoutedEventArgs e)
        {
            RegistrarVehiculo regVeh= new RegistrarVehiculo();
            regVeh.Show();
        }
    }
}
